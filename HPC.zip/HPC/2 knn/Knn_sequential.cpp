#include<iostream>
#include<math.h>
#include<string.h>
#include<fstream>
#include<stdlib.h>
#include<typeinfo>
using namespace std;

double atof (const char* str);

float euclidean(float ex1[1][4],float ex2[1][4]){
	
	float distance=0;
	
	for(int i=0;i<4;i++){
		distance += pow((ex1[0][i]-ex2[0][i]),2);
	}
	distance = sqrt(distance);
	
	return distance;
};

string classify(float dist[][2], int K, string iris_data_raw[][5]){

	int classOneCount = 0 ;
	int classTwoCount =0 ;
	int classThreeCount = 0;

	string classOne = "Iris-setosa";
	string classTwo = "Iris-versicolor";
	string classThree = "Iris-virginica";
	
	string result = "";
	
	cout<<"Counting nearest classes"<<endl;
	
	for (int i=0;i<K;i++){
		if(iris_data_raw[(int)dist[i][0]][4]==classOne){
			classOneCount++;
		}
		else if(iris_data_raw[(int)dist[i][0]][4]==classTwo){
			classTwoCount++;
		}
		else
			classThreeCount++;
	}
	
	if(classOneCount>classTwoCount){
		if(classOneCount>classThreeCount)
			result = classOne;
		else
			result = classThree;
	}
	else
	{
		if(classTwoCount>classThreeCount)
			result = classTwo;
		else
			result = classThree;
	}
	return result;
}

int main(){
	
	string iris_data_raw[150][5];
	float iris_data[150][4];
	
	int K;
	int example_number;
	
	char parse_to_float[3];
	
	ifstream iris_file;
	iris_file.open("iris.csv");
	
	while(!iris_file.eof()){
		for(int i =0;i<150;i++){
			for(int j=0 ; j<5;j++){
				getline(iris_file,iris_data_raw[i][j],',');
			}
		}
	}
	
	//Add missing entry
	iris_data_raw[0][0] = "5.1";
	
	
	//convert to float
	for(int i =0;i<150;i++){
			for(int j=0 ; j<4;j++){
				strcpy(parse_to_float,iris_data_raw[i][j].c_str());
				iris_data[i][j] = atof(parse_to_float);		
			}
		}
		
	//Ask for User input of K and which example to classify
	
	cout<<"Enter the number of nearest neighbours to be considered (K)"<<endl;
	cin>>K;
	cout<<"Enter the example number to be classified (0-149) :"<<endl;
	cin>>example_number;
		
	//Calculate Distances between example_number and all other examples
	float distances[149][2];
	
	for(int i=0;i<150;i++){
		distances[i][0]=i;
		distances[i][1]=euclidean(&iris_data[example_number],&iris_data[i+1]);
	}
	
	cout<<"Distances to all Neighbours are :"<<endl;
	
	for (int i=0;i<150;i++)
		cout<<distances[i][0]<<'\t'<<distances[i][1]<<endl;

	//Bubble sort Distances
	
	float swap_distance;	
	float swap_index;
	for (int i =0;i<148;i++){
		for (int j=0;j<148-i-1;j++){
			if(distances[j][1]>distances[j+1][1]){
				swap_distance = distances[j][1];
				swap_index = distances[j][0];
				distances[j][1] = distances[j+1][1];
				distances[j][0] = distances[j+1][0];
				distances[j+1][1] = swap_distance;
				distances[j+1][0] = swap_index;
			}
		}
	}
	
	//Display the K nearest neighbours
	
	cout<<"The K nearest Neighbours are : "<<endl;
	
	for(int i=0;i<K;i++){
		for(int j=0;j<5;j++){
			cout<<iris_data_raw[(int)distances[i][0]][j]<<'\t';
		}
		cout<<endl;
	}
	
	cout<<"Distances to the K-nearest neighbours are :"<<endl;
	//Display Distances to K nearest neighbours
	for (int i=0;i<K;i++)
		cout<<distances[i][0]<<'\t'<<distances[i][1]<<endl;

	cout<<"The example "<<example_number<<" belongs to the class : "<<classify(distances,K,iris_data_raw)<<endl;
		
	return 0;
}
