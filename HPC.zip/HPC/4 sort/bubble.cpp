#include<iostream>
#include<cstdlib>
#include<omp.h>
#include<time.h>
using namespace std;

int main()
{
	clock_t start,end;
	
	int n;
	cout<<"\nEnter the value of n : ";
	cin>>n;
	int a[n];
	
	start = clock();
	
	omp_set_num_threads(1000);
	
	#pragma omp parallel for
	for(int i=0;i<n;i++)
	{
		a[i] = rand()%100;
	}
	
	
	for(int i=0;i<n;i++)
	{
		#pragma omp parallel for
		for(int j=i%2;j<n-1;j+=2)
		{
			if(a[j]>a[j+1])
			{
				int temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
		}
	}
	
	cout<<"\nThe values : \n";
	
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<endl;
	}
	end = clock();
	cout<<"\nExecution time : "<<((double)(end-start)/CLOCKS_PER_SEC)<<" s"<<endl;
}
