#include<iostream>
#include<cstdlib>
#include<omp.h>
#include<time.h>
using namespace std;

void mergesort(int a[], int i, int j);
void merge(int a[], int i1, int j1, int i2, int j2);

int main()
{
	clock_t start,end;
	
	int n;
	cout<<"\nEnter the value of n : ";
	cin>>n;
	int a[n];
	
	start = clock();
	omp_set_num_threads(1000);
	
	#pragma omp parallel for
	for(int i=0;i<n;i++)
	{
		a[i] = rand()%100;
	}
	
	mergesort(a,0,n-1);
	
	cout<<"\nThe values : \n";
	
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<endl;
	}
	end = clock();
	cout<<"\nExecution time : "<<((double)(end-start)/CLOCKS_PER_SEC)<<" s"<<endl;
}



void mergesort(int a[], int i, int j)
{
	if(i<j)
	{
		int mid = (i+j)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				mergesort(a,i,mid);
			}
			#pragma omp section
			{
				mergesort(a,mid+1,j);
			}
		}
		merge(a,i,mid,mid+1,j);
	}
}


void merge(int a[], int i1, int j1, int i2, int j2)
{
	int i=i1,j=i2,k=0,n;
	n = j1-i1+j2-i2+2;
	int temp[n];
	
	while(i<=j1 && j<=j2)
	{
		if(a[i] <= a[j])
		{
			temp[k++] = a[i++];
		}
		else
		{
			temp[k++] = a[j++];
		}
	}
	
	while(i<=j1)
		temp[k++] = a[i++];
		
	while(j<=j2)
		temp[k++] = a[j++];

	
	#pragma omp parallel for	
	for(i=i1; i<=j2; i++)
	{
		a[i] = temp[i-i1];
	}
}
